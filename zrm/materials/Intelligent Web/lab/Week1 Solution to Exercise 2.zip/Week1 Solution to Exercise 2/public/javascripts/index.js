function checkForErrors(isLoginCorrect) {
    if (!isLoginCorrect) {
        alert('login or password is incorrect');
    }
}